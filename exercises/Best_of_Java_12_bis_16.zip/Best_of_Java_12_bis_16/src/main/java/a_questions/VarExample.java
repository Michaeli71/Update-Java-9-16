package a_questions;

import java.util.ArrayList;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class VarExample {

	public static void main(String[] args) {
		
		ArrayList<String> names = new ArrayList<>();
		names.add("Tim");
		//names.add(72);
		
		//List.of
	}

}
