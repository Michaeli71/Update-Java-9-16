package a_questions;


/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
// FOLIEN!!!
public class InstanceOfExample {

	public static void main(String[] args) {
		
	    Object obj2 = "BACSGsJAHG";
	    
        if (obj2 instanceof String) 
        {
            String str2 = (String)obj2;
            if (str2.length() > 5 && str2.startsWith("BA"))
            {
                System.out.println("Länge: " + str2.length());                
            }
        }
        
	    if (obj2 instanceof String str2 && str2.length() > 5 && str2.startsWith("BA"))
	    {
	        //str2 ="THOMAS_jashjadhkjadhj";
	        System.out.println("Länge: " + str2.length());
	    }
	}
}
