package b_slides;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class TextBlocksExample {

	public static void main(String[] args) {

		String jsonObj = """
				{
				    name: "Mike",
				    birthday: "1971-02-07",
				    comment: "Text blocks are nice!"
				}
			""";

		System.out.println(jsonObj);

		String text = """
				This is a string splitted in several smaller \
				jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj \
				jjjjjjjjjjjjjjjjjjjjjjjj \
				jjjjjjjjjjjj strings""";

		System.out.println(text);
		System.out.println(text.getClass());

	}

}
