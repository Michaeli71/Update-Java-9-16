package b_slides;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class SwitchExample {

	enum Color {
		RED, GREEN, BLUE, NEW_VERY_SPECIAL;
	}

	public static void main(String[] args) {

		Color selectedColor = Color.RED;

		String result = switch (selectedColor) {
		case RED -> "Red";
		case GREEN -> "Green";
		case BLUE -> "Blue";
		case NEW_VERY_SPECIAL -> throw new UnsupportedOperationException("Unimplemented case: " + selectedColor);
		default -> throw new IllegalArgumentException("Unexpected value: " + selectedColor);
		};

		int number = 42;
		
		String answer = switch (number) {
		case 42 -> "The ultimate answer";
		case 77 ->  "Not bad";
		case 666 -> "Devil is around";
		default -> throw new IllegalArgumentException("Unexpected value: " + number);
		case 1234 -> "NEW CASE";
		};
	}
}
