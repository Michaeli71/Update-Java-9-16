package solutions.part_1_2;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018/2019 by Michael Inden 
 */
public class Exercise13_Instanceof_Records_V1 
{
	// Verbesserung ohne Cast, aber instancoef verstösst gegen Open Closed
	public double computeArea(final Object figure) 
	{
		if (figure instanceof Square square) 
		{
			return square.sideLength * square.sideLength;
		} 
		else if (figure instanceof Circle circle) 
		{
			return circle.radius * circle.radius * Math.PI;
		}
		throw new IllegalArgumentException("figure is not a recognized figure");
	}
	
	record Square(double sideLength) {
	}
	
	record Circle(double radius) {
	}
}
