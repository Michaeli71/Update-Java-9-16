package solutions.part_1_2;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018/2019 by Michael Inden 
 */
public class Exercise10_Records 
{
	record Square(double sideLength) {}

	record Circle(double radius) {}
}
