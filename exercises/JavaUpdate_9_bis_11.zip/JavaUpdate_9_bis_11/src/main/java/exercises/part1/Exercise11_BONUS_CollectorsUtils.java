package exercises.part1;

import java.util.function.Predicate;
import java.util.stream.Collector;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise11_BONUS_CollectorsUtils 
{
	public static <T, A, R> Collector<T, A, R> filtering(final Predicate<? super T> filter, 
			                                             final Collector<T, A, R> collector) 
	{
		  return null; // TODO
	}
}
