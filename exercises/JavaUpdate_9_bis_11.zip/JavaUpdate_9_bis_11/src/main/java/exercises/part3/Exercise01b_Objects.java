package exercises.part3;

import java.time.Instant;
import java.time.Year;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise01b_Objects 
{
	public static Instant dateToInstantWithNowAsDefault_NewStyle(final Date origDate) 
	{
		final Date adjustedDate = /* TODO */ null;
		
		return adjustedDate.toInstant();
	}

	public static Instant dateToInstantWithNowAsDefault_OldStyle(final Date origDate) 
	{
		Date adjustedDate = origDate;
		if (adjustedDate == null)
		{
			adjustedDate = new Date();
		}
			
		return adjustedDate.toInstant();
	}
}
