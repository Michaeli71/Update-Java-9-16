package exercises.part3;

import java.time.Duration;
import java.time.temporal.ChronoUnit;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise08_DurationMiscMethodsExample 
{
	public static void main(String[] args) 
	{		
		final Duration somePeriodOfTime = Duration.ofHours(3).plusMinutes(45).plusSeconds(57);		
		
		// Achtung: Fallstrick: TimeUnit != ChronoUnit => java.util.concurrent.TimeUnit;
		// TODO
		
		// Wandle die Zeitdauer in Minuten und was ist der reine Minutenanteil?
		// TODO
		
		// Wie viel mal 5 Minten sind das? Wie oft passen 22 Sekunden hinein?
		// TODO	
	}
}
