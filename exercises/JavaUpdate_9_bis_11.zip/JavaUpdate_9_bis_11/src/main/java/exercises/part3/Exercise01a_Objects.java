package exercises.part3;

import java.time.Year;
import java.util.Objects;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise01a_Objects 
{
	public void adjustStudyStartYearNewStyle(Person person, Year beginOfStudy) 
	{
		// TODO

		// Rest of method
	}
	
	public void adjustStudyStartYearOldStyle(Person person, Year beginOfStudy) 
	{
		if (person == null) 
		{
			throw new NullPointerException("person cannot be null!");
		}
		if (beginOfStudy == null) 
		{
			throw new NullPointerException("beginOfStudy cannot be null!");
		}
		
		// Rest of method
	}
}
