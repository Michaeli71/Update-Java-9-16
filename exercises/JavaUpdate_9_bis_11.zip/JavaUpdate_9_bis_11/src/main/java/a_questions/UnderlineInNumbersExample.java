package a_questions;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class UnderlineInNumbersExample {

	public static void main(String[] args) {
		
		int one_million = 1_000_000;
		
		//int one_million_2 = 1_0_0_0_0_0_0;
		
		int asByte = 0b000_1111_0101_1001;
		System.out.println(asByte);	
	}
}
