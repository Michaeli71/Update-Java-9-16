package a_questions;

import java.util.Objects;

public class ObjectsExample {

	private String info;
	private String second;
	private Long third;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Files.readString(path) => String.lines() => Stream<String>
		// Files.readAllLines(path) => List<String> => stream()
		// Files.lines(path) => Stream<String>
	}

	void doSomething(String info, String second, Long third)
	{
		this.info = Objects.requireNonNull(info);
		this.second = Objects.requireNonNull(second);
		this.third = Objects.requireNonNull(third);
		
		//
	}
}
