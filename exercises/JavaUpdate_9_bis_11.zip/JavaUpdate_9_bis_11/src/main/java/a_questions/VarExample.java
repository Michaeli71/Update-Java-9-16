package a_questions;

import java.util.ArrayList;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class VarExample {

	public static void main(String[] args) {
		
		ArrayList<String> names = new ArrayList<>();
		names.add("Tim");
		//names.add(72);
		
		/*
		final var mixedContent = new ArrayList<>();
		mixedContent.add("Strange with var");
		mixedContent.add(42);
		*/
		
		var personAgeMapping = Map.of("Tim", 47L, "Tom", 12L, "Michael", 47L);
		
		var entrySet = personAgeMapping.entrySet();

		final Function<Map.Entry<String, Long>, Character> firstChar = entry -> entry.getKey().charAt(0);

		final Predicate<Map.Entry<String, Long>> isAdult = entry -> entry.getValue() >= 18;

		var filteredPersons = personAgeMapping.entrySet().stream().
				              collect(Collectors.groupingBy(firstChar, Collectors.filtering(isAdult, Collectors.toSet())));
	}
}

